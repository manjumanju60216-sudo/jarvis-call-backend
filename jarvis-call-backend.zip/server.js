const express = require("express");
const bodyParser = require("body-parser");
const app = express();

app.use(bodyParser.urlencoded({ extended: false }));

const allowedNumber = "8534033910";

app.post("/incoming-call", (req, res) => {
    const caller = req.body.From || "";

    if (caller.includes(allowedNumber)) {
        const twiml = `
        <Response>
            <Say language="hi-IN">
                Hello, main Jarvis bol raha hoon. Aapka naam bataiye please?
            </Say>

            <Gather input="speech" timeout="5" language="hi-IN" action="/speech">
                <Say language="hi-IN">Aap apna naam bataye.</Say>
            </Gather>
        </Response>
        `;
        res.type("text/xml");
        return res.send(twiml);
    }

    const rejectTwiml = `
    <Response>
        <Reject reason="busy"/>
    </Response>
    `;
    res.type("text/xml");
    res.send(rejectTwiml);
});

app.post("/speech", (req, res) => {
    const speech = req.body.SpeechResult || "Kuch sunaai nahi diya";

    const reply = `
    <Response>
        <Say language="hi-IN">
            ${speech} ji, main aapki kis tareh madad kar sakta hoon?
        </Say>
    </Response>
    `;

    res.type("text/xml");
    res.send(reply);
});

app.listen(3000, () => console.log("Jarvis backend running on port 3000"));
